// 모달 열기 및 닫기 기능
function openModal(id) { 
    document.getElementById('modal-' + id).style.display = 'block'; 
}

function closeModal(id) { 
    document.getElementById('modal-' + id).style.display = 'none'; 
}

// 대용량 원본 영상은 별도 보관합니다. 공식 채널 링크는 index.html에 있습니다.
document.addEventListener('DOMContentLoaded',()=>{
 const video=document.getElementById('random-video');
 if(video){video.poster='img/고세구.webp';video.removeAttribute('autoplay');}
});
